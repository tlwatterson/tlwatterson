<h2>Validating a Tool to Measure Pharmacist Fatigue: Implications for the Quadruple Aim</h2>

By
Taylor Lee Watterson


A dissertation submitted in partial fulfillment of
the requirements for the degree of


Doctor of Philosophy
(Health Services Research in Pharmacy)


at the
UNIVERSITY OF WISCONSIN-MADISON
2022</br></br>


<h4>Date of final oral examination: May 5, 2022 </h4> </br>
<h4>The dissertation is approved by the following members of the Final Oral Committee:</h4></br>

* Michelle A Chui, Professor, Social and Administrative Sciences in Pharmacy </br>
* Linsey M Steege, Associate Professor, School of Nursing</br>
* David A Mott, Professor, Social and Administrative Sciences in Pharmacy</br>
* James H Ford II, Associate Professor, Social and Administrative Sciences in Pharmacy </br>
* Edward C Portillo, Assistant Professor (CHS), Pharmacy Practice </br>

