- 👋 Hi, I’m @tlwatterson
- 📫 How to reach me: tlwatt@uic.edu
- 😄 Pronouns: she/her/hers
- ✨ Bio: I am committed to enacting genuine change within the community through serving others, providing compassionate care, and conducting meaningful research that promotes patient safety. The goal of my research and the Systems-based Collaborative Research for PatienT Safety Lab (SCRPTS Lab, pronounced scripts) is to markedly improve patient safety through a systems-based, human factors approach and by partnering with multidisciplinary researchers, scientists, practitioners, and community stakeholders to develop and study interventions that improve care.

<!---
tlwatterson/tlwatterson is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
